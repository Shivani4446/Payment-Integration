<?php

echo "Hello world";
?>